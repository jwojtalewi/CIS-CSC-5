/* 
 * File:   main.cpp
 * Author: John Wojtalewicz
 * Created on June 23, 2022, 4:36 PM
 * Purpose: A program that displays personal information.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

// Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map inputs to outputs -> The Process
    
    //Display Results
    cout
            <<"John Wojtalewicz\n"
            <<"24367 Mesa Ridge Ln, Moreno Valley, 92557\n"
            <<"(951)237-8494\n"
            <<"Computer Science";
    
    //Exit stage right
    return 0;
}

